#!/bin/bash

# Generate a random number between 1 and 3 (inclusive)
random_seconds=$(( (RANDOM % 3) + 1 ))

echo "Hello! I am ${id}"

# Sleep for the random number of seconds
sleep $random_seconds

echo "Goodbye from ${id}"
